window.__be = window.__be || {};
window.__be.id = "656d04cb1490f000071f7d69";
(function() {
    var be = document.createElement('script'); be.type = 'text/javascript'; be.async = true;
    be.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.chatbot.com/widget/plugin.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(be, s);
})();