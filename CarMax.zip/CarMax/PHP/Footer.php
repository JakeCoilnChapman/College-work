<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="CSS/Footer.css">
</head>
<body>
    <div class="footer">
    
        <div class="LeftSide">
            <h4>About Us</h4>
                <p>CarMax is dedicated to providing an exceptional automotive experience. 
                <p>Our passion for cars drives us to deliver top-notch services and 
                information to car enthusiasts around the world.</p>
        </div>
        <div class="mid">
                <h4>Contact Us</h4>
                <p>Email:  CarMax@Gamil.com<br>
                <p>Phone: 01234 456852</p>
        </div>
        <div class="Rightside">
        <h4>Quick Links</h4>
            <ul>
                <li><a href="\CarMax\Cars.php">Cars</a></li>
                <li><a href="\CarMax\Manufactures.php">Manufactures</a></li>
                <li><a href="\CarMax\Contact and Location.php">Contact and Location</a></li>
                <li><a href="\CarMax\Servicing.php">Servicing</a></li>
                <li><a href="\CarMax\About.php">About</a></li>
            </ul>
        </div>
    </div>
</body>