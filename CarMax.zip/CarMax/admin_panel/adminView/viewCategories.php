
<div >
  <h3>Car Brands</h3>
  <table class="table ">
    <thead>
      <tr>
        <th class="text-center">ID</th>
        <th class="text-center">Brand Name</th>
        <th class="text-center">Brand Image</th>
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    <?php
      include "C:/xampp/htdocs/CarMax/PHP/Connection.php";
      $sql="SELECT * from carbrands";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <td><?=$count?></td>
      <td><?=$row["BrandName"]?></td>
      <td><img height='100px' src='\CarMax\ASSETS\Car Brands/<?=$row["BrandImage"]?>'><td>   
      <td><button class="btn btn-primary" >Edit</button></td> 
      <td><button class="btn btn-danger" style="height:40px" onclick="categoryDelete('<?=$row['BrandID']?>')">Delete</button></td>
      </tr>
      <?php
            $count=$count+1;
          }
        }
      ?>
  </table>

  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-secondary" style="height:40px" data-toggle="modal" data-target="#myModal">
    Add Brand
  </button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">New Car Brand </h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form  enctype='multipart/form-data' action="./controller/addCatController.php" method="POST">
            <div class="form-group">
              <label for="b_name">Brand Name:</label>
              <input type="text" class="form-control" name="b_name" required>
              <label for="Image">Image Name including file type:</label>
              <input type="text" class="form-control" name=Image" required> 
            </div>
            
            <div class="form-group">
              <button type="submit" class="btn btn-secondary" name="upload" style="height:40px">Add Category</button>
            </div>
          </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <script type="text/javascript" src="./assets/js/ajaxWork.js"></script>    
    <script type="text/javascript" src="./assets/js/script.js"></script>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
  
</div>
   