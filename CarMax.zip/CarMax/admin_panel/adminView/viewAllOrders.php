<div id="ordersBtn" >
  <h2>Test Drive Booked</h2>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Test drive ID</th>
        <th>User ID</th>
        <th>Customer name</th>
        <th>CarID</th>
        <th>Car name</th>
        <th>Test Date</th>
        <th>More Details</th>
     </tr>
    </thead>
     <?php
      include "C:/xampp/htdocs/CarMax/PHP/Connection.php";
      $sql="SELECT * from testdrive, cartable,users_infroamtion  WHERE testdrive.CarID=cartable.CarID";
      $result=$conn-> query($sql);
      
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
       <tr>
          <td><?=$row["TestDriveID"]?></td>
          <td><?=$row["UsersInforID"]?></td>
          <td><?=$row["Name"]?><?=$row["Surname"]?></td>
          <td><?=$row["CarID"]?></td>
          <td><?=$row["CarName"]?></td>
          <td><?=$row["Date"]?></td>
           <?php 
                /*if($row["order_status"]==0){*/
                            
            ?>
                
            <?php
                        
                /*}else{*/
            ?>
                
            <?php
            }
                /*if($row["pay_status"]==0){*/
            ?>
                
            <?php
                        
            /*}else if($row["pay_status"]==1){*/
            ?>
              
            <?php
                /*}*/
            ?>
              
        <td><a class="btn btn-primary openPopup" data-href="./adminView/viewEachOrder.php?orderID=<?=$row['TestDriveID']?>" href="javascript:void(0);">View</a></td>
        </tr>
    <?php
            
        }
      /*}*/
    ?>
     
  </table>
   
</div>
<!-- Modal -->
<div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Order Details</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="order-view-modal modal-body">
        
        </div>
      </div><!--/ Modal content-->
    </div><!-- /Modal dialog-->
  </div>
<script>
     //for view order modal  
    $(document).ready(function(){
      $('.openPopup').on('click',function(){
        var dataURL = $(this).attr('data-href');
    
        $('.order-view-modal').load(dataURL,function(){
          $('#viewModal').modal({show:true});
        });
      });
    });
 </script>