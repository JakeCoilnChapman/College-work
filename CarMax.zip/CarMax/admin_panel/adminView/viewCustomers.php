<div >
  <h2>All Customers</h2>
  <table class="table ">
    <thead>
      <tr>
        <th class="text-center">ID</th>
        <th class="text-center">Username</th>
        <th class="text-center">Name</th>
        <th class="text-center">DOB</th>
        <th class="text-center">Email</th>
        <th class="text-center">PNumber</th>
        <th class="text-center">Location</th>
        <th class="text-center">Joining Date</th>
      </tr>
    </thead>
    <?php
       include "C:/xampp/htdocs/CarMax/PHP/Connection.php";
      $sql="SELECT * from users_infroamtion where Admin=0";
      $result=$conn-> query($sql);
      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
           
    ?>
    <tr>
      <td><?=$count?></td>
      <td><?=$row["Username"]?></td>
      <td><?=$row["Name"]?> <?=$row["Surname"]?></td>
      <td><?=$row["DOB"]?></td>
      <td><?=$row["Email"]?></td>
      <td><?=$row["PNumber"]?></td>
      <td><?=$row["Location"]?></td>
      <td><?=$row["Join_Date"]?></td>
    </tr>
    <?php
            $count=$count+1;
           
        }
    }
    ?>
  </table>