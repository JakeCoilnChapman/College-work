<?php

    include "C:/xampp/htdocs/CarMax/PHP/Connection.php";
    
    $c_id=$_POST['record'];
    $query="DELETE FROM carbrands where BrandID='$c_id'";

    $data=mysqli_query($conn,$query);

    if($data){
        echo"Category Item Deleted";
    }
    else{
        echo"Not able to delete";
    }
    
?>