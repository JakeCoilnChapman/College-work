<?php
    include "C:/xampp/htdocs/CarMax/PHP/Connection.php";
    if(isset($_POST['upload']))
    {
       
        $Brandname = $_POST['b_name'];
        $Image = $_POST['Image'];
       
         $insert = mysqli_query($conn,"INSERT INTO carbrands
         (BrandName,BrandImage) 
         VALUES ('$Brandname',$Image)");
 
         if(!$insert)
         {
             echo mysqli_error($conn);
             header("Location: ../dashboard.php?category=error");
         }
         else
         {
             echo "Records added successfully.";
             header("Location: \CarMax\admin_panel\AdminMan.php?category=success");
         }
     
    }
        
?>