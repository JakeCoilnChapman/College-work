score = 0
RaptorsScore = 0
IceScore = 0
TargersScore = 0
TomCatsScore = 0
JohnScore = 0
RoseScore = 0
LuckScore = 0
JoScore = 0
TeamScore = [RaptorsScore,
             IceScore,
             TargersScore,
             TomCatsScore]
Teams =["Raptors","Ice","Targers","TomCats"]
Individual = ["John","Rose","Luck","Jo"]
IndividualScore = [JohnScore,
                   RoseScore,
                   LuckScore,
                   JoScore]
#all of this above is pefined code 
o1 = input("Enter team or New Score?:")
if o1 == "t":
    while True:
       individualName = input("Enter name of individual leave blank if not needed:")
       Individual.append(individualName)
       TeamName = input("Enter name of Team leave blank if not needed:")
       Teams.append(TeamName)
       end = input("Is that all of the name? Y/N:")
       if end == "Y":
          break
K = input("Do you want to enter any scores?")

while True:
    if o1 or K == "NS":
        print("Teams",Teams)
        print("Individual", Individual)
        TeIn = input("Teams or Individual?:(T/I)")
        if TeIn == "I":
            L = input("Would you like to enter individual score?(L)")
            if L != "John":
                v = int(input("How many point for John?:"))
                JohnScore = JohnScore + v
                print("Score for ",L," have been updated")
                x = input("Is that all?:")
                if x =="M":
                            break
            if L != "Rose":
                a = int(input("How many point for Rose?:"))
                RoseScore = RoseScore + a
                print("Score for ",L," have been updated")
                p = input("Is that all?:")
                if p =="j":
                    break
            if L != "Luck":
                c = int(input("How many point for Luck?:"))
                LuckScore = LuckScore + c
                print("Score for ",L," have been updated")
                q = input("Is that all?:")
                if q =="j":
                    break
            if L != "Jo":
                z = int(input("How many point for Jo?:"))
                JoScore = JoScore + z
                print("Score for ",L," have been updated")
                Q = input("Is that all?:")
                if Q =="j":
                    break    
            h= print("Do you want to enter Team Score?:(h)")
            h = input("Would you like to enter team score?(h)")
            if h != "Raptors":
                d = int(input("How many point for Raptors?:"))
                RaptorsScore = RaptorsScore + d
                print("Score for ",h," have been updated")
                M = input("Is that all?:")
                if M =="M":
                            break
            if h != "Ice":
                   i = int(input("How many point for Ice?:"))
                   IceScore = IceScore + i
                   print("Score for ",h," have been updated")
                   M = input("Is that all?:")
                   if M =="M":
                            break


            if h := "Targers":
                 q = int(input("How many point for Targers?:"))
                 TargersScore = TargersScore + q
                 print("Score for ",h," have been updated")
                 M = input("Is that all?:")
                 if M =="M":
                         break

            if h := "TomCats":
                 j = int(input("How many point for TomCats?:"))
                 TomCatsScore = TomCatsScore + j
                 print("Score for ",h," have been updated")
                 M = input("Is that all?:")
                 if M =="M":
                             break
                            
                           


                            

import csv
fields = ['TeamName','TeamScore','Individual','IndividualScore']
Rows = [["Raptors",RaptorsScore,"John",JohnScore],
        ["Ice",IceScore,"Rose",RoseScore],
        ["Targers",TargersScore,"Luck",LuckScore],
        ["TomCats",TomCatsScore,"Jo",JoScore]]
filename = "Score.csv"
with open(filename, 'w') as csvfile:
    csvwriter = csv.writer(csvfile)
    csvwriter.writerow(fields)
    csvwriter.writerows(Rows)
                       
print(RaptorsScore)
print(IceScore)
print(TargersScore)
print(TomCatsScore)






##op1 = input("Are you entering a new team or individual? t/i:")
##
##if op1 == "i":
##        IndividualName = input("Enter name of individual:")
##        Individual.append(IndividualName)
##        o2 = input("Press B to return:")
##
##elif op1 == "t":
##        TeamName = input("Enter name of Team:")
##        Teams.append(TeamName)
##        o2 = input("Press B to return:")
##
##
##input("Are you entering a new team or individual? t/i:")
##
